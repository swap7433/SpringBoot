package com.DigiMart.DigiMart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DigiMartApplicationTests {

	@Test
	void contextLoads() {
	}

}
