package com.DigiMart.DigiMart.DigiBeans;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DigiProduct {

	@Autowired
	private DigiCategory Dcategry_Name;
	public DigiProduct() {
		super();
		System.out.println("Product are Displayed");
		
	}
	
	private String prod_name;
	public DigiProduct(String prod_name) {
		this.prod_name = prod_name;
		System.out.println("Product Name:" + prod_name);
	}
        public String getProduct_details() {
		return prod_name;
	}

        public DigiCategory getCategry_Name() {
    		return Dcategry_Name;
    	}
        
}
