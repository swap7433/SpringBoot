package com.DigiMart.DigiMart;
import org.springframework.context.annotation.*;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
@Configuration
@ComponentScan(basePackages="com.DigiMart.DigiMart.DigiBeans")
public class DigiConfig {

}
