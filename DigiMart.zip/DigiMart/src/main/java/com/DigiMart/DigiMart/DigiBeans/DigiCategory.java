package com.DigiMart.DigiMart.DigiBeans;


import org.springframework.stereotype.Component;


@Component
public class DigiCategory {

	public DigiCategory() {
		super();
		System.out.println("Product Category has been Displayed");
		
	}

	private String category_Name;
	public DigiCategory(String category_Name) {
		this.category_Name = category_Name;
		System.out.println("Category Details:" + category_Name);
	}
        public String getCategory() {
		return category_Name;
	}

}
