-- password in plaintext: "password"
INSERT INTO USER (user_id, password, email, username, name, last_name, active)
VALUES
  (1, '$2a$06$OAPObzhRdRXBCbk7Hj/ot.jY3zPwR8n7/mfLtKIgTzdJa4.6TwsIm', 'user@mail.com', 'user', 'Name', 'Surname',
   1);
-- password in plaintext: "password"
INSERT INTO USER (user_id, password, email, username, name, last_name, active)
VALUES
  (2, '$2a$06$OAPObzhRdRXBCbk7Hj/ot.jY3zPwR8n7/mfLtKIgTzdJa4.6TwsIm', 'swap@gmail.com', 'Swapnil', 'Swapnil', 'Sonawnae', 1);
-- password in plaintext: "password"
INSERT INTO USER (user_id, password, email, username, name, last_name, active)
VALUES (3, '$2a$06$OAPObzhRdRXBCbk7Hj/ot.jY3zPwR8n7/mfLtKIgTzdJa4.6TwsIm', 'name@gmail.com', 'namesurname', 'Name',
        'Surname', 1);

INSERT INTO ROLE (role_id, role)
VALUES (1, 'ROLE_ADMIN');
INSERT INTO ROLE (role_id, role)
VALUES (2, 'ROLE_USER');

INSERT INTO USER_ROLE (user_id, role_id)
VALUES (1, 1);
INSERT INTO USER_ROLE (user_id, role_id)
VALUES (1, 2);
INSERT INTO USER_ROLE (user_id, role_id)
VALUES (2, 2);
INSERT INTO USER_ROLE (user_id, role_id)
VALUES (3, 2);

INSERT INTO PRODUCT (name, description, quantity, price)
VALUES ('headphones', 'Extreme Bass headphones', 5, 400);
INSERT INTO PRODUCT (name, description, quantity, price)
VALUES ('WireLess Mouse', 'Wireless Mouse for all Compatibility', 5, 500);
INSERT INTO PRODUCT (name, description, quantity, price)
VALUES ('Lenovo Laptop', 'Lenovo Ideapad 320 ', 3, 35000.00);
INSERT INTO PRODUCT (name, description, quantity, price)
VALUES ('Laptop Bag', 'All types of Laptop', 40, 600.00);
INSERT INTO PRODUCT (name, description, quantity, price)
VALUES ('Pendrives', 'Sandisk !6GB 3.0 pendrive', 80, 450.45);
INSERT INTO PRODUCT (name, description, quantity, price)
VALUES ('Wireless Keyboard', 'For gaming with BackLight ', 80, 1200.00);
INSERT INTO PRODUCT (name, description, quantity, price)
VALUES ('MI Redmi note 7 pro', '', 7, 13999.00);
INSERT INTO PRODUCT (name, description, quantity, price)
VALUES ('Camera', 'Imported Canon camera from USA', 10, 85000.00);